import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const supabaseUrl = 'https://lldbmljqgfaxsgelkdam.supabase.co';
const supabaseAnonKey = 'sb_publishable_K6e8FZBchvSQV08N1RFxTQ_N9GoPdX1';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  runApp(const VchatApp());
}

final supabase = Supabase.instance.client;

class VchatApp extends StatelessWidget {
  const VchatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vchat',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087E72)),
        useMaterial3: true,
      ),
      home: supabase.auth.currentSession == null
          ? const AuthPage()
          : const InboxPage(),
    );
  }
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool isLogin = true;
  bool busy = false;
  String? error;

  Future<void> submit() async {
    setState(() { busy = true; error = null; });
    try {
      if (isLogin) {
        await supabase.auth.signInWithPassword(
          email: email.text.trim(), password: password.text,
        );
      } else {
        await supabase.auth.signUp(
          email: email.text.trim(), password: password.text,
        );
      }
      if (!mounted) return;
      if (supabase.auth.currentSession != null) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const InboxPage()),
        );
      } else {
        setState(() => error = 'Cek email untuk konfirmasi akun, lalu masuk.');
      }
    } on AuthException catch (e) {
      setState(() => error = e.message);
    } catch (e) {
      setState(() => error = 'Terjadi kesalahan: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 420),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Icon(Icons.forum_rounded, size: 64, color: Color(0xFF087E72)),
              const SizedBox(height: 12),
              const Text('Vchat', textAlign: TextAlign.center,
                style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
              const Text('Chat simpel, cepat, dan ringan',
                textAlign: TextAlign.center),
              const SizedBox(height: 32),
              TextField(controller: email, keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(labelText: 'Email',
                  border: OutlineInputBorder())),
              const SizedBox(height: 12),
              TextField(controller: password, obscureText: true,
                decoration: const InputDecoration(labelText: 'Password',
                  border: OutlineInputBorder())),
              if (error != null) ...[
                const SizedBox(height: 12),
                Text(error!, style: const TextStyle(color: Colors.red)),
              ],
              const SizedBox(height: 18),
              FilledButton(
                onPressed: busy ? null : submit,
                child: Text(busy ? 'Memproses...' : isLogin ? 'Masuk' : 'Daftar'),
              ),
              TextButton(
                onPressed: busy ? null : () => setState(() => isLogin = !isLogin),
                child: Text(isLogin ? 'Belum punya akun? Daftar' : 'Sudah punya akun? Masuk'),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

class InboxPage extends StatefulWidget {
  const InboxPage({super.key});
  @override
  State<InboxPage> createState() => _InboxPageState();
}

class _InboxPageState extends State<InboxPage> {
  List<Map<String, dynamic>> users = [];
  bool loading = true;
  String? error;
  final myId = supabase.auth.currentUser!.id;

  @override
  void initState() {
    super.initState();
    loadUsers();
    supabase.channel('vchat-inbox-$myId')
      .onPostgresChanges(
        event: PostgresChangeEvent.all,
        schema: 'public',
        table: 'messages',
        callback: (_) => loadUsers(),
      ).subscribe();
  }

  Future<void> loadUsers() async {
    try {
      final data = await supabase.from('profiles')
          .select('id, username')
          .neq('id', myId)
          .order('username');
      if (!mounted) return;
      setState(() { users = List<Map<String, dynamic>>.from(data); loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() { error = e.toString(); loading = false; });
    }
  }

  Future<void> logout() async {
    await supabase.auth.signOut();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const AuthPage()), (_) => false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Vchat', style: TextStyle(fontWeight: FontWeight.bold)),
      actions: [IconButton(onPressed: logout, icon: const Icon(Icons.logout),
        tooltip: 'Keluar')],
    ),
    body: loading
      ? const Center(child: CircularProgressIndicator())
      : error != null
        ? Center(child: Padding(padding: const EdgeInsets.all(20),
            child: Text('Gagal memuat pengguna: $error')))
        : users.isEmpty
          ? const Center(child: Text('Belum ada pengguna lain. Ajak teman daftar Vchat.'))
          : ListView.separated(
              itemCount: users.length,
              separatorBuilder: (_, __) => const Divider(height: 1, indent: 72),
              itemBuilder: (context, i) {
                final user = users[i];
                return ListTile(
                  leading: CircleAvatar(child: Text(
                    (user['username'] as String? ?? '?').substring(0, 1).toUpperCase())),
                  title: Text(user['username'] as String? ?? 'Pengguna'),
                  subtitle: const Text('Mulai percakapan'),
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => ChatPage(
                      otherId: user['id'] as String,
                      otherName: user['username'] as String? ?? 'Pengguna',
                    ),
                  )),
                );
              },
            ),
    floatingActionButton: FloatingActionButton(
      onPressed: loadUsers, child: const Icon(Icons.refresh),
      tooltip: 'Muat ulang pengguna',
    ),
  );
}

class ChatPage extends StatefulWidget {
  final String otherId;
  final String otherName;
  const ChatPage({super.key, required this.otherId, required this.otherName});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final input = TextEditingController();
  final scroll = ScrollController();
  List<Map<String, dynamic>> messages = [];
  bool loading = true;
  bool sending = false;
  String? error;
  final myId = supabase.auth.currentUser!.id;
  RealtimeChannel? channel;

  @override
  void initState() {
    super.initState();
    loadMessages();
    channel = supabase.channel('vchat-chat-${widget.otherId}-$myId')
      .onPostgresChanges(
        event: PostgresChangeEvent.all,
        schema: 'public',
        table: 'messages',
        callback: (_) => loadMessages(),
      )..subscribe();
  }

  Future<void> loadMessages() async {
    try {
      final data = await supabase.from('messages').select()
        .or('and(sender_id.eq.$myId,receiver_id.eq.${widget.otherId}),and(sender_id.eq.${widget.otherId},receiver_id.eq.$myId)')
        .order('created_at');
      if (!mounted) return;
      setState(() { messages = List<Map<String, dynamic>>.from(data); loading = false; });
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (scroll.hasClients) scroll.jumpTo(scroll.position.maxScrollExtent);
      });
    } catch (e) {
      if (!mounted) return;
      setState(() { error = e.toString(); loading = false; });
    }
  }

  Future<void> send() async {
    final text = input.text.trim();
    if (text.isEmpty || sending) return;
    setState(() => sending = true);
    input.clear();
    try {
      await supabase.from('messages').insert({
        'sender_id': myId, 'receiver_id': widget.otherId, 'body': text,
      });
      await loadMessages();
    } catch (e) {
      input.text = text;
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Pesan gagal dikirim: $e')));
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  @override
  void dispose() {
    input.dispose();
    scroll.dispose();
    if (channel != null) supabase.removeChannel(channel!);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.otherName)),
    body: Column(children: [
      Expanded(child: loading
        ? const Center(child: CircularProgressIndicator())
        : error != null
          ? Center(child: Text('Gagal memuat chat: $error'))
          : ListView.builder(
              controller: scroll,
              padding: const EdgeInsets.all(12),
              itemCount: messages.length,
              itemBuilder: (_, i) {
                final m = messages[i];
                final mine = m['sender_id'] == myId;
                return Align(
                  alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    constraints: const BoxConstraints(maxWidth: 300),
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: mine ? const Color(0xFFD8F5E9) : Colors.grey.shade200,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(m['body'] as String? ?? ''),
                  ),
                );
              },
            )),
      SafeArea(child: Padding(
        padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
        child: Row(children: [
          Expanded(child: TextField(controller: input,
            minLines: 1, maxLines: 4,
            decoration: InputDecoration(hintText: 'Tulis pesan...',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(24)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10)),
            onSubmitted: (_) => send())),
          const SizedBox(width: 8),
          IconButton.filled(onPressed: sending ? null : send,
            icon: const Icon(Icons.send)),
        ]),
      )),
    ]),
  );
}
