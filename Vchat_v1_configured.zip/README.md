# Vchat v1.0 — starter Android online chat

Versi awal ini memakai Flutter untuk aplikasi Android dan Supabase untuk autentikasi,
database PostgreSQL, serta realtime.

## Fitur awal
- Daftar dan masuk menggunakan email/password
- Daftar pengguna Vchat
- Chat pribadi satu lawan satu
- Kirim dan terima pesan teks
- Pembaruan percakapan melalui Supabase Realtime

## 1. Siapkan Supabase
1. Buat project di https://supabase.com
2. Buka SQL Editor, jalankan seluruh isi `supabase/schema.sql`.
3. Buka Project Settings > API, salin Project URL dan anon/public key.
4. Buka `lib/main.dart`, ganti `ISI_SUPABASE_URL` dan `ISI_SUPABASE_ANON_KEY`.
5. Pastikan Realtime aktif untuk tabel `messages` di Database > Publications.
6. Untuk tes awal, pengaturan konfirmasi email boleh disesuaikan di Authentication > Providers > Email.

## 2. Siapkan Flutter
Pasang Flutter SDK dan Android Studio, lalu dari folder proyek jalankan:

```bash
flutter pub get
flutter run
```

Untuk membuat APK:

```bash
flutter build apk --release
```

APK akan berada di `build/app/outputs/flutter-apk/app-release.apk`.

## Catatan penting
- Ini starter project, belum APK siap instal. Build harus dilakukan dengan Flutter SDK.
- Username dibuat otomatis dari bagian email sebelum tanda `@`. Username harus unik.
- Jangan pernah memasukkan `service_role` key ke aplikasi Android. Gunakan hanya anon/public key; keamanan data dijaga dengan Row Level Security (RLS).
- Untuk produksi, tambahkan validasi username, penanganan akun, blokir/lapor pengguna, pagination pesan, dan kebijakan anti-spam.
